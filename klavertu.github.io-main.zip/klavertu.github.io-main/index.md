Here you can say lots of fun things about your site.

Maybe say a some things about yourself.

Or maybe what you plan to blog about.
